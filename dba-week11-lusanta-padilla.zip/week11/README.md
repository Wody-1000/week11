1. Why does running a query in the SQL Editor as postgres not prove that a policy works?

The SQL Editor runs as the postgres role, which bypasses Row Level Security completely, so no policy is ever checked. Every query returns every row whether or not the policies are correct, which means a broken policy and a working one look identical. To prove a policy works, we have to switch to the anon or authenticated role and set the login claims ourselves, as we did in the tests.

2. What would happen to our policies if a request used the secret key, and why is that dangerous in a browser?

The secret key (the service_role key) also bypasses RLS, so a request using it would ignore every policy and could read, change, or delete any row in any table. A browser is dangerous because anyone can open the developer tools, copy the key from the page or the network requests, and then have full access to the whole database. The secret key must stay on a trusted server and never go in front-end code.