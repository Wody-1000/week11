-- ===== 5.2 WRITE TESTS =====

-- W1: Member A adds a review under their own name
-- Expected: SUCCEEDS, 1 row returned
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"}}', true);
INSERT INTO public.reviews (book_id, member_id, rating, comment)
VALUES (3, 1, 5, 'W1 test review')
RETURNING *;
ROLLBACK;

-- W2: Member A tries to write a review in Member B's name
-- Expected: ERROR "new row violates row-level security policy for table reviews"
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"}}', true);
INSERT INTO public.reviews (book_id, member_id, rating, comment)
VALUES (3, 2, 1, 'W2 review pretending to be Member B');
ROLLBACK;

-- W3: Member A updates their own member row
-- Expected: SUCCEEDS, 1 row returned
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"}}', true);
UPDATE public.members
SET full_name = 'Member A Renamed'
WHERE member_id = 1
RETURNING *;
ROLLBACK;

-- W4: Member A tries to update Member B's member row
-- Expected: blocked silently, rows_updated = 0 (no error)
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"}}', true);
WITH u AS (
  UPDATE public.members SET full_name = 'Hacked'
  WHERE member_id = 2
  RETURNING 1
)
SELECT count(*) AS rows_updated FROM u;
ROLLBACK;

-- W5: Member A tries to point their own row at Member B's login
-- Expected: ERROR from WITH CHECK "new row violates row-level security policy for table members"
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"}}', true);
UPDATE public.members
SET user_id = 'PASTE-MEMBER-B-UUID-HERE'
WHERE member_id = 1;
ROLLBACK;

-- W6: Member A tries to delete Member B's review
-- Expected: blocked silently, rows_deleted = 0 (no error)
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"}}', true);
WITH d AS (
  DELETE FROM public.reviews
  WHERE member_id = 2
  RETURNING 1
)
SELECT count(*) AS rows_deleted FROM d;
ROLLBACK;

-- W7: Member A tries to delete their own member row (nobody may delete members)
-- Expected: blocked silently, rows_deleted = 0 (no error)
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"}}', true);
WITH d AS (
  DELETE FROM public.members
  WHERE member_id = 1
  RETURNING 1
)
SELECT count(*) AS rows_deleted FROM d;
ROLLBACK;

-- W8: Visitor (anon) tries to add a book
-- Expected: ERROR "new row violates row-level security policy for table books"
BEGIN;
SET LOCAL ROLE anon;
SELECT set_config('request.jwt.claims', '{"role":"anon"}', true);
INSERT INTO public.books (title, author)
VALUES ('W8 Visitor Book', 'Nobody');
ROLLBACK;

-- ===== 5.3 FORGED-CLAIM TEST =====
-- The token claims librarian in user_metadata (the user can edit this),
-- but app_metadata says member (only the server can set this).
-- Policies trust app_metadata only, so this person should have NO librarian rights.

-- F1: Forged claim, READ
-- Expected: members 1, books 3, loans 2, reviews 2 (same as a normal member)
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"},"user_metadata":{"role":"librarian"}}', true);
SELECT
  (SELECT count(*) FROM public.members) AS members_seen,
  (SELECT count(*) FROM public.books)   AS books_seen,
  (SELECT count(*) FROM public.loans)   AS loans_seen,
  (SELECT count(*) FROM public.reviews) AS reviews_seen;
ROLLBACK;

-- F2: Forged claim, WRITE (add a book)
-- Expected: ERROR "new row violates row-level security policy for table books"
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"},"user_metadata":{"role":"librarian"}}', true);
INSERT INTO public.books (title, author)
VALUES ('F2 Forged Librarian Book', 'Nobody');
ROLLBACK;

-- F3: Forged claim, WRITE (change a loan)
-- Expected: blocked silently, rows_updated = 0 (no error)
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claims',
  '{"sub":"PASTE-MEMBER-A-UUID-HERE","role":"authenticated","app_metadata":{"role":"member"},"user_metadata":{"role":"librarian"}}', true);
WITH u AS (
  UPDATE public.loans SET due_on = current_date + 365
  RETURNING 1
)
SELECT count(*) AS rows_updated FROM u;
ROLLBACK; 

-- 7.1 Every policy on our four tables
SELECT
  tablename   AS "table",
  policyname  AS "name",
  cmd         AS "operation",
  roles,
  permissive
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('members', 'books', 'loans', 'reviews')
ORDER BY tablename, cmd, policyname;

-- 7.2 Is RLS on for every table?
SELECT
  c.relname          AS "table",
  c.relrowsecurity   AS rls_enabled
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('members', 'books', 'loans', 'reviews')
ORDER BY c.relname;