-- 01_auth_schema.sql : link tables to Supabase Auth, add seed data

-- A. Link each member row to exactly one login.
-- UNIQUE means one login can only have one member row.
-- ON DELETE CASCADE: if the login is deleted, its member row is deleted too, so no orphan rows are left behind.
ALTER TABLE public.members
  ADD COLUMN user_id uuid NOT NULL UNIQUE
  REFERENCES auth.users(id) ON DELETE CASCADE;

-- B. Link each review to the member who wrote it.
-- ON DELETE CASCADE: if a member is removed, their reviews are removed too, so no review points to a missing member.
ALTER TABLE public.reviews
  ADD COLUMN member_id bigint NOT NULL
  REFERENCES public.members(member_id) ON DELETE CASCADE;

-- C. Set roles in app_metadata (the secure place for roles).
UPDATE auth.users
SET raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"member"}'::jsonb
WHERE email IN ('dp@gmail.com', 'wl@gmail.com');

UPDATE auth.users
SET raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"librarian"}'::jsonb
WHERE email = 'lib@gmail.com';

-- D. Seed data: books
INSERT INTO public.books (title, author, copies_available) VALUES
  ('Noli Me Tangere', 'Jose Rizal', 3),
  ('El Filibusterismo', 'Jose Rizal', 2),
  ('Ibong Adarna', 'Anonymous', 4);

-- E. Seed data: members (one per login)
INSERT INTO public.members (full_name, email, user_id) VALUES
  ('Member A', 'dp@gmail.com', 'c80af930-152c-4e2d-a614-6f5b54c09658'),
  ('Member B', 'wl@gmail.com', '96095942-ebd3-4a16-8df3-09f85a88e002');

-- F. Seed data: loans (2 per member)
INSERT INTO public.loans (member_id, book_id, due_on, returned_on)
SELECT m.member_id, b.book_id, current_date + 14, NULL
FROM public.members m, public.books b
WHERE m.email = 'dp@gmail.com' AND b.title = 'Noli Me Tangere';

INSERT INTO public.loans (member_id, book_id, due_on, returned_on)
SELECT m.member_id, b.book_id, current_date - 3, current_date - 5
FROM public.members m, public.books b
WHERE m.email = 'dp@gmail.com' AND b.title = 'Ibong Adarna';

INSERT INTO public.loans (member_id, book_id, due_on, returned_on)
SELECT m.member_id, b.book_id, current_date + 10, NULL
FROM public.members m, public.books b
WHERE m.email = 'wl@gmail.com' AND b.title = 'El Filibusterismo';

INSERT INTO public.loans (member_id, book_id, due_on, returned_on)
SELECT m.member_id, b.book_id, current_date - 1, current_date - 2
FROM public.members m, public.books b
WHERE m.email = 'wl@gmail.com' AND b.title = 'Noli Me Tangere';

-- G. Seed data: reviews (1 per member)
INSERT INTO public.reviews (book_id, member_id, rating, comment)
SELECT b.book_id, m.member_id, 5, 'A classic that is still worth reading.'
FROM public.members m, public.books b
WHERE m.email = 'dp@gmail.com' AND b.title = 'Noli Me Tangere';

INSERT INTO public.reviews (book_id, member_id, rating, comment)
SELECT b.book_id, m.member_id, 4, 'Heavier than the first book, but strong.'
FROM public.members m, public.books b
WHERE m.email = 'wl@gmail.com' AND b.title = 'El Filibusterismo';

-- H. Supporting indexes (one for every column a policy filters by)

-- H. Supporting indexes (one for every column a policy filters by)

-- members.user_id is declared UNIQUE in section A, so Postgres already
-- created an index for it automatically (members_user_id_key).
-- Policies that use it: "Members read own row, librarians read all",
-- "Members create own row", "Members update own row".
-- (No extra index needed. The UNIQUE index already does this job.)

-- Used by the policy "Members read own loans, librarians read all"
CREATE INDEX IF NOT EXISTS idx_loans_member_id
  ON public.loans (member_id);

-- Used by the policies "Members add own reviews",
-- "Members update own reviews", and "Members delete own reviews"
CREATE INDEX IF NOT EXISTS idx_reviews_member_id
  ON public.reviews (member_id);