-- 00_starter.sql : Mini Library starting tables
DROP TABLE IF EXISTS public.reviews CASCADE;
DROP TABLE IF EXISTS public.loans CASCADE;
DROP TABLE IF EXISTS public.books CASCADE;
DROP TABLE IF EXISTS public.members CASCADE;
CREATE TABLE public.members (
member_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
full_name text NOT NULL,
email text NOT NULL UNIQUE,
joined_at date NOT NULL DEFAULT current_date
);
CREATE TABLE public.books (
book_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
title text NOT NULL,
author text NOT NULL,
copies_available int NOT NULL DEFAULT 1 CHECK (copies_available >= 0)
);
CREATE TABLE public.loans (
loan_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
member_id bigint NOT NULL REFERENCES public.members(member_id) ON DELETE
CASCADE,
book_id bigint NOT NULL REFERENCES public.books(book_id) ON DELETE
RESTRICT,
borrowed_on date NOT NULL DEFAULT current_date,

due_on date NOT NULL,
returned_on date
);
CREATE TABLE public.reviews (
review_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
book_id bigint NOT NULL REFERENCES public.books(book_id) ON DELETE CASCADE,
rating int NOT NULL CHECK (rating BETWEEN 1 AND 5),
comment text
);
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;