-- 02_policies.sql : RLS policies for the Mini Library

-- A. Make sure RLS is on for all four tables
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.books   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loans   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- B. BOOKS: everyone reads, only librarians write
CREATE POLICY "Anyone reads books"
  ON public.books FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Librarians add books"
  ON public.books FOR INSERT
  TO authenticated
  WITH CHECK (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian');

CREATE POLICY "Librarians update books"
  ON public.books FOR UPDATE
  TO authenticated
  USING (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian')
  WITH CHECK (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian');

CREATE POLICY "Librarians delete books"
  ON public.books FOR DELETE
  TO authenticated
  USING (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian');

-- C. MEMBERS: own row only, librarians read all, nobody deletes
CREATE POLICY "Members read own row, librarians read all"
  ON public.members FOR SELECT
  TO authenticated
  USING (
    user_id = (select auth.uid())
    OR ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian'
  );

CREATE POLICY "Members create own row"
  ON public.members FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- WITH CHECK stops a member from pointing their row at a different login
CREATE POLICY "Members update own row"
  ON public.members FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- No DELETE policy on members on purpose: with RLS on, no policy means
-- nobody can delete a member through the API.

-- D. LOANS: members read own loans, librarians read all and manage everything
CREATE POLICY "Members read own loans, librarians read all"
  ON public.loans FOR SELECT
  TO authenticated
  USING (
    member_id IN (
      SELECT m.member_id FROM public.members m
      WHERE m.user_id = (select auth.uid())
    )
    OR ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian'
  );

CREATE POLICY "Librarians add loans"
  ON public.loans FOR INSERT
  TO authenticated
  WITH CHECK (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian');

CREATE POLICY "Librarians update loans"
  ON public.loans FOR UPDATE
  TO authenticated
  USING (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian')
  WITH CHECK (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian');

CREATE POLICY "Librarians delete loans"
  ON public.loans FOR DELETE
  TO authenticated
  USING (((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'librarian');

-- E. REVIEWS: everyone reads, members manage only their own
CREATE POLICY "Anyone reads reviews"
  ON public.reviews FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Members add own reviews"
  ON public.reviews FOR INSERT
  TO authenticated
  WITH CHECK (
    member_id IN (
      SELECT m.member_id FROM public.members m
      WHERE m.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Members update own reviews"
  ON public.reviews FOR UPDATE
  TO authenticated
  USING (
    member_id IN (
      SELECT m.member_id FROM public.members m
      WHERE m.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    member_id IN (
      SELECT m.member_id FROM public.members m
      WHERE m.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Members delete own reviews"
  ON public.reviews FOR DELETE
  TO authenticated
  USING (
    member_id IN (
      SELECT m.member_id FROM public.members m
      WHERE m.user_id = (select auth.uid())
    )
  );